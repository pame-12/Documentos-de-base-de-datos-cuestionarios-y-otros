package com.example.gestionnotas;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Button btnAgregar, btnVer, btnEditar;
    private FrameLayout frameContainer;
    private View vistaActual;
    private DatabaseHelper db;

    // Variables para agregar nota
    private EditText etTitulo, etDescripcion;
    private ImageView ivPreview;
    private Button btnSeleccionarImagen, btnGuardar;
    private String rutaImagenSeleccionada = "";

    // Variables para ver y editar notas
    private ListView lvNotas, lvNotasEditar;
    private NotaAdapter adapter, adapterEditar;
    private List<Nota> listaNotas;
    private TextView tvNoHayNotas, tvNoHayNotasEditar;

    // Launcher para seleccionar imagen
    private ActivityResultLauncher<Intent> imagePickerLauncher;
    private ActivityResultLauncher<Intent> editImageLauncher;

    private static final int REQUEST_PERMISSIONS = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar base de datos
        db = new DatabaseHelper(this);

        // Inicializar botones
        btnAgregar = findViewById(R.id.btnAgregar);
        btnVer = findViewById(R.id.btnVer);
        btnEditar = findViewById(R.id.btnEditar);
        frameContainer = findViewById(R.id.frameContainer);

        // Configurar launchers para seleccionar imagen
        configurarImagePickers();

        // Solicitar permisos
        solicitarPermisos();

        // Configurar listeners de los botones principales
        btnAgregar.setOnClickListener(v -> mostrarVistaAgregar());
        btnVer.setOnClickListener(v -> mostrarVistaVer());
        btnEditar.setOnClickListener(v -> mostrarVistaEditar());

        // Mostrar vista por defecto (Agregar)
        mostrarVistaAgregar();
    }

    private void configurarImagePickers() {
        // Launcher para agregar nota
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        if (imageUri != null) {
                            guardarImagenLocal(imageUri, false, null);
                        }
                    }
                }
        );

        // Launcher para editar nota (se configurará dinámicamente)
        editImageLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    // Este se maneja dentro del diálogo de edición
                }
        );
    }

    private void solicitarPermisos() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            // Android 13+
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                        REQUEST_PERMISSIONS);
            }
        } else {
            // Android 12 y anteriores
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_PERMISSIONS);
            }
        }
    }

    // ==================== VISTA AGREGAR NOTA ====================

    private void mostrarVistaAgregar() {
        LayoutInflater inflater = LayoutInflater.from(this);
        vistaActual = inflater.inflate(R.layout.fragment_agregar, null);
        frameContainer.removeAllViews();
        frameContainer.addView(vistaActual);

        // Inicializar componentes
        etTitulo = vistaActual.findViewById(R.id.etTitulo);
        etDescripcion = vistaActual.findViewById(R.id.etDescripcion);
        ivPreview = vistaActual.findViewById(R.id.ivPreview);
        btnSeleccionarImagen = vistaActual.findViewById(R.id.btnSeleccionarImagen);
        btnGuardar = vistaActual.findViewById(R.id.btnGuardar);

        // Limpiar campos
        etTitulo.setText("");
        etDescripcion.setText("");
        ivPreview.setImageResource(R.drawable.ic_image_default);
        rutaImagenSeleccionada = "";

        // Configurar listeners
        btnSeleccionarImagen.setOnClickListener(v -> seleccionarImagen());
        btnGuardar.setOnClickListener(v -> guardarNota());
    }

    private void seleccionarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imagePickerLauncher.launch(intent);
    }

    private void guardarImagenLocal(Uri imageUri, boolean esEdicion, ImageView imageViewDestino) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            // Crear directorio si no existe
            File directorioImagenes = new File(getFilesDir(), "imagenes_notas");
            if (!directorioImagenes.exists()) {
                directorioImagenes.mkdirs();
            }

            // Crear nombre único para la imagen
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                    Locale.getDefault()).format(new Date());
            String nombreArchivo = "IMG_" + timeStamp + ".jpg";
            File archivoImagen = new File(directorioImagenes, nombreArchivo);

            // Guardar imagen comprimida
            FileOutputStream outputStream = new FileOutputStream(archivoImagen);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream);
            outputStream.close();

            // Guardar ruta
            if (!esEdicion) {
                rutaImagenSeleccionada = archivoImagen.getAbsolutePath();
                ivPreview.setImageBitmap(bitmap);
            } else if (imageViewDestino != null) {
                imageViewDestino.setTag(archivoImagen.getAbsolutePath());
                imageViewDestino.setImageBitmap(bitmap);
            }

            Toast.makeText(this, "Imagen seleccionada", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al cargar imagen", Toast.LENGTH_SHORT).show();
        }
    }

    private void guardarNota() {
        String titulo = etTitulo.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();

        // Validaciones
        if (titulo.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa un título", Toast.LENGTH_SHORT).show();
            etTitulo.requestFocus();
            return;
        }

        if (descripcion.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa una descripción", Toast.LENGTH_SHORT).show();
            etDescripcion.requestFocus();
            return;
        }

        // Crear nota
        Nota nota = new Nota(titulo, descripcion, rutaImagenSeleccionada);

        // Guardar en base de datos
        long id = db.agregarNota(nota);

        if (id > 0) {
            Toast.makeText(this, "✓ Nota guardada exitosamente", Toast.LENGTH_SHORT).show();
            // Limpiar campos
            etTitulo.setText("");
            etDescripcion.setText("");
            ivPreview.setImageResource(R.drawable.ic_image_default);
            rutaImagenSeleccionada = "";
        } else {
            Toast.makeText(this, "✗ Error al guardar nota", Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== VISTA VER NOTAS ====================

    private void mostrarVistaVer() {
        LayoutInflater inflater = LayoutInflater.from(this);
        vistaActual = inflater.inflate(R.layout.fragment_ver, null);
        frameContainer.removeAllViews();
        frameContainer.addView(vistaActual);

        // Inicializar componentes
        lvNotas = vistaActual.findViewById(R.id.lvNotas);
        tvNoHayNotas = vistaActual.findViewById(R.id.tvNoHayNotas);

        // Cargar notas
        cargarNotas();
    }

    private void cargarNotas() {
        listaNotas = db.obtenerTodasLasNotas();

        if (listaNotas.isEmpty()) {
            lvNotas.setVisibility(View.GONE);
            tvNoHayNotas.setVisibility(View.VISIBLE);
        } else {
            lvNotas.setVisibility(View.VISIBLE);
            tvNoHayNotas.setVisibility(View.GONE);

            adapter = new NotaAdapter(this, listaNotas);
            lvNotas.setAdapter(adapter);

            // Click en una nota para ver detalles
            lvNotas.setOnItemClickListener((parent, view, position, id) -> {
                Nota nota = listaNotas.get(position);
                mostrarDetallesNota(nota);
            });
        }
    }

    private void mostrarDetallesNota(Nota nota) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_detalle_nota, null);

        TextView tvTitulo = dialogView.findViewById(R.id.tvDetallesTitulo);
        TextView tvDescripcion = dialogView.findViewById(R.id.tvDetallesDescripcion);
        ImageView ivImagen = dialogView.findViewById(R.id.ivDetallesImagen);

        tvTitulo.setText(nota.getTitulo());
        tvDescripcion.setText(nota.getDescripcion());

        if (nota.getImagen() != null && !nota.getImagen().isEmpty()) {
            try {
                Bitmap bitmap = BitmapFactory.decodeFile(nota.getImagen());
                if (bitmap != null) {
                    ivImagen.setImageBitmap(bitmap);
                } else {
                    ivImagen.setImageResource(R.drawable.ic_image_default);
                }
            } catch (Exception e) {
                ivImagen.setImageResource(R.drawable.ic_image_default);
            }
        } else {
            ivImagen.setImageResource(R.drawable.ic_image_default);
        }

        builder.setView(dialogView)
                .setPositiveButton("Cerrar", null)
                .show();
    }

    // ==================== VISTA EDITAR NOTAS ====================

    private void mostrarVistaEditar() {
        LayoutInflater inflater = LayoutInflater.from(this);
        vistaActual = inflater.inflate(R.layout.fragment_editar, null);
        frameContainer.removeAllViews();
        frameContainer.addView(vistaActual);

        // Inicializar componentes
        lvNotasEditar = vistaActual.findViewById(R.id.lvNotasEditar);
        tvNoHayNotasEditar = vistaActual.findViewById(R.id.tvNoHayNotasEditar);

        // Cargar notas
        cargarNotasParaEditar();
    }

    private void cargarNotasParaEditar() {
        listaNotas = db.obtenerTodasLasNotas();

        if (listaNotas.isEmpty()) {
            lvNotasEditar.setVisibility(View.GONE);
            tvNoHayNotasEditar.setVisibility(View.VISIBLE);
        } else {
            lvNotasEditar.setVisibility(View.VISIBLE);
            tvNoHayNotasEditar.setVisibility(View.GONE);

            adapterEditar = new NotaAdapter(this, listaNotas);
            lvNotasEditar.setAdapter(adapterEditar);

            // Click para editar
            lvNotasEditar.setOnItemClickListener((parent, view, position, id) -> {
                Nota nota = listaNotas.get(position);
                mostrarDialogoEditar(nota);
            });

            // Long click para eliminar
            lvNotasEditar.setOnItemLongClickListener((parent, view, position, id) -> {
                Nota nota = listaNotas.get(position);
                mostrarDialogoEliminar(nota);
                return true;
            });
        }
    }

    private void mostrarDialogoEditar(Nota nota) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_editar_nota, null);

        EditText etTituloEdit = dialogView.findViewById(R.id.etTituloEdit);
        EditText etDescripcionEdit = dialogView.findViewById(R.id.etDescripcionEdit);
        ImageView ivPreviewEdit = dialogView.findViewById(R.id.ivPreviewEdit);
        Button btnCambiarImagen = dialogView.findViewById(R.id.btnCambiarImagenEdit);

        // Cargar datos actuales
        etTituloEdit.setText(nota.getTitulo());
        etDescripcionEdit.setText(nota.getDescripcion());

        // Guardar ruta de imagen actual en el tag del ImageView
        ivPreviewEdit.setTag(nota.getImagen());

        if (nota.getImagen() != null && !nota.getImagen().isEmpty()) {
            try {
                Bitmap bitmap = BitmapFactory.decodeFile(nota.getImagen());
                if (bitmap != null) {
                    ivPreviewEdit.setImageBitmap(bitmap);
                } else {
                    ivPreviewEdit.setImageResource(R.drawable.ic_image_default);
                }
            } catch (Exception e) {
                ivPreviewEdit.setImageResource(R.drawable.ic_image_default);
            }
        } else {
            ivPreviewEdit.setImageResource(R.drawable.ic_image_default);
        }

        // Configurar botón cambiar imagen
        btnCambiarImagen.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

            ActivityResultLauncher<Intent> tempLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Uri imageUri = result.getData().getData();
                            if (imageUri != null) {
                                guardarImagenLocal(imageUri, true, ivPreviewEdit);
                            }
                        }
                    }
            );
            tempLauncher.launch(intent);
        });

        // Mostrar diálogo
        AlertDialog dialog = builder.setView(dialogView)
                .setTitle("Editar Nota")
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();

        dialog.show();

        // Override del botón positivo para validar antes de cerrar
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String nuevoTitulo = etTituloEdit.getText().toString().trim();
            String nuevaDescripcion = etDescripcionEdit.getText().toString().trim();
            String nuevaRutaImagen = (String) ivPreviewEdit.getTag();

            if (nuevoTitulo.isEmpty()) {
                Toast.makeText(this, "El título no puede estar vacío",
                        Toast.LENGTH_SHORT).show();
                etTituloEdit.requestFocus();
                return;
            }

            if (nuevaDescripcion.isEmpty()) {
                Toast.makeText(this, "La descripción no puede estar vacía",
                        Toast.LENGTH_SHORT).show();
                etDescripcionEdit.requestFocus();
                return;
            }

            // Actualizar nota
            nota.setTitulo(nuevoTitulo);
            nota.setDescripcion(nuevaDescripcion);
            nota.setImagen(nuevaRutaImagen);

            int resultado = db.actualizarNota(nota);
            if (resultado > 0) {
                Toast.makeText(this, "✓ Nota actualizada", Toast.LENGTH_SHORT).show();
                cargarNotasParaEditar();
                dialog.dismiss();
            } else {
                Toast.makeText(this, "✗ Error al actualizar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarDialogoEliminar(Nota nota) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar Nota")
                .setMessage("¿Estás seguro de que deseas eliminar la nota \"" +
                        nota.getTitulo() + "\"?")
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    db.eliminarNota(nota.getId());

                    // Eliminar imagen asociada si existe
                    if (nota.getImagen() != null && !nota.getImagen().isEmpty()) {
                        File archivoImagen = new File(nota.getImagen());
                        if (archivoImagen.exists()) {
                            archivoImagen.delete();
                        }
                    }

                    Toast.makeText(this, "✓ Nota eliminada", Toast.LENGTH_SHORT).show();
                    cargarNotasParaEditar();
                })
                .setNegativeButton("Cancelar", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null) {
            db.close();
        }
    }
}