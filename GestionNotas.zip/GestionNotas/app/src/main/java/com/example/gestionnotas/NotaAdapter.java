package com.example.gestionnotas;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class NotaAdapter extends BaseAdapter {
    private Context context;
    private List<Nota> listaNotas;
    private LayoutInflater inflater;

    public NotaAdapter(Context context, List<Nota> listaNotas) {
        this.context = context;
        this.listaNotas = listaNotas;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return listaNotas.size();
    }

    @Override
    public Object getItem(int position) {
        return listaNotas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return listaNotas.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_nota, parent, false);
            holder = new ViewHolder();
            holder.tvTitulo = convertView.findViewById(R.id.tvTitulo);
            holder.tvDescripcion = convertView.findViewById(R.id.tvDescripcion);
            holder.ivImagen = convertView.findViewById(R.id.ivImagen);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Nota nota = listaNotas.get(position);
        holder.tvTitulo.setText(nota.getTitulo());
        holder.tvDescripcion.setText(nota.getDescripcion());

        // Cargar imagen si existe
        if (nota.getImagen() != null && !nota.getImagen().isEmpty()) {
            try {
                Bitmap bitmap = BitmapFactory.decodeFile(nota.getImagen());
                holder.ivImagen.setImageBitmap(bitmap);
            } catch (Exception e) {
                holder.ivImagen.setImageResource(R.drawable.ic_image_default);
            }
        } else {
            holder.ivImagen.setImageResource(R.drawable.ic_image_default);
        }

        return convertView;
    }

    static class ViewHolder {
        TextView tvTitulo;
        TextView tvDescripcion;
        ImageView ivImagen;
    }

    // Método para actualizar la lista
    public void actualizarLista(List<Nota> nuevaLista) {
        this.listaNotas = nuevaLista;
        notifyDataSetChanged();
    }
}
