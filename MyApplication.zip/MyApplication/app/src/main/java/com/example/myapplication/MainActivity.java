package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvCantidad, tvSaludo;
    private EditText etNombre;
    private Button btnLongitud, btnPeso, btnTemperatura;
    private String cantidad = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        tvCantidad = findViewById(R.id.tvCantidad);
        tvSaludo = findViewById(R.id.tvSaludo);
        etNombre = findViewById(R.id.etNombre);
        btnLongitud = findViewById(R.id.btnLongitud);
        btnPeso = findViewById(R.id.btnPeso);
        btnTemperatura = findViewById(R.id.btnTemperatura);


        setConversionButtonsEnabled(false);


        etNombre.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void afterTextChanged(Editable s) {
                String nombre = etNombre.getText().toString().trim();
                if(!nombre.isEmpty()){
                    tvSaludo.setText("Hola, " + nombre);
                    setConversionButtonsEnabled(true);
                } else {
                    tvSaludo.setText("Hola, ingresa tu nombre");
                    setConversionButtonsEnabled(false);
                }
            }
        });

        // Botones numéricos
        int[] botones = {R.id.btn0,R.id.btn1,R.id.btn2,R.id.btn3,R.id.btn4,R.id.btn5,R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9};
        for(int id: botones){
            Button btn = findViewById(id);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cantidad += btn.getText().toString();
                    tvCantidad.setText(cantidad);
                }
            });
        }

        // Botón punto
        Button btnPunto = findViewById(R.id.btnPunto);
        btnPunto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!cantidad.contains(".")){
                    cantidad += ".";
                    tvCantidad.setText(cantidad);
                }
            }
        });

        // Botón reiniciar
        Button btnReiniciar = findViewById(R.id.btnReiniciar);
        btnReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cantidad = "";
                tvCantidad.setText("0");
            }
        });

        // Botones de conversión
        btnLongitud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertirLongitud();
            }
        });

        btnPeso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertirPeso();
            }
        });

        btnTemperatura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertirTemperatura();
            }
        });
    }

    private void setConversionButtonsEnabled(boolean enabled){
        btnLongitud.setEnabled(enabled);
        btnPeso.setEnabled(enabled);
        btnTemperatura.setEnabled(enabled);
    }

    private void convertirLongitud(){
        if(cantidad.isEmpty()) return;
        double numero;
        try{
            numero = Double.parseDouble(cantidad);
        } catch (NumberFormatException e){
            tvCantidad.setText("Número inválido");
            return;
        }
        double resultado = numero * 3.28084; // metros a pies
        tvCantidad.setText(numero + " m = " + String.format("%.2f", resultado) + " ft");
    }

    private void convertirPeso(){
        if(cantidad.isEmpty()) return;
        double numero;
        try{
            numero = Double.parseDouble(cantidad);
        } catch (NumberFormatException e){
            tvCantidad.setText("Número inválido");
            return;
        }
        double resultado = numero * 2.20462; // kg a libras
        tvCantidad.setText(numero + " kg = " + String.format("%.2f", resultado) + " lb");
    }

    private void convertirTemperatura(){
        if(cantidad.isEmpty()) return;
        double numero;
        try{
            numero = Double.parseDouble(cantidad);
        } catch (NumberFormatException e){
            tvCantidad.setText("Número inválido");
            return;
        }
        double resultado = numero * 9/5 + 32; // Celsius a Fahrenheit
        tvCantidad.setText(numero + " °C = " + String.format("%.2f", resultado) + " °F");
    }
}

