package com.example.myapplication3;

import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private TextView textView;
    private TextView instructionsText;
    private ConstraintLayout mainLayout;
    private SeekBar gradientSeekBar;

    // Variables para detectar swipe
    private float startX, startY;
    private static final int MIN_SWIPE_DISTANCE = 150;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        initializeViews();

        // Configurar gradiente inicial
        setupGradientControl();

        // Configurar detección de swipe
        setupSwipeDetection();

        // Actualizar instrucciones según orientación
        updateInstructions();

        // Configurar EditText para que no muestre teclado virtual
        editText.setShowSoftInputOnFocus(false);
        editText.requestFocus();
    }

    private void initializeViews() {
        editText = findViewById(R.id.inputField);
        textView = findViewById(R.id.resultText);
        instructionsText = findViewById(R.id.instructions);
        mainLayout = findViewById(R.id.mainLayout);
        gradientSeekBar = findViewById(R.id.gradientSeekBar);
    }

    private void setupGradientControl() {
        if (gradientSeekBar != null) {
            gradientSeekBar.setMax(100);
            gradientSeekBar.setProgress(50);

            gradientSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    updateGradient(progress);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        // Establecer gradiente inicial
        updateGradient(50);
    }

    private void updateGradient(int progress) {
        // Interpolar entre blanco y negro
        float ratio = progress / 100f;

        // Calcular colores intermedios
        int topColor = interpolateColor(Color.WHITE, Color.BLACK, ratio);
        int bottomColor = interpolateColor(Color.BLACK, Color.WHITE, ratio);

        GradientDrawable gradient = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{topColor, bottomColor}
        );

        mainLayout.setBackground(gradient);
    }

    private int interpolateColor(int colorStart, int colorEnd, float ratio) {
        int startR = Color.red(colorStart);
        int startG = Color.green(colorStart);
        int startB = Color.blue(colorStart);

        int endR = Color.red(colorEnd);
        int endG = Color.green(colorEnd);
        int endB = Color.blue(colorEnd);

        int r = (int) (startR + ratio * (endR - startR));
        int g = (int) (startG + ratio * (endG - startG));
        int b = (int) (startB + ratio * (endB - startB));

        return Color.rgb(r, g, b);
    }

    private void setupSwipeDetection() {
        mainLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getX();
                        startY = event.getY();
                        return true;

                    case MotionEvent.ACTION_UP:
                        float endX = event.getX();
                        float endY = event.getY();
                        float deltaX = endX - startX;
                        float deltaY = endY - startY;

                        // Verificar si es un swipe horizontal válido
                        if (Math.abs(deltaX) > MIN_SWIPE_DISTANCE &&
                                Math.abs(deltaX) > Math.abs(deltaY)) {
                            handleSwipe(deltaX, event.getY());
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private void handleSwipe(float deltaX, float yPosition) {
        // Obtener altura de la pantalla
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        boolean isBottomHalf = yPosition > screenHeight / 2;

        if (isBottomHalf) {
            if (deltaX > 0) {
                // Swipe de izquierda a derecha -> Cerrar aplicación
                Toast.makeText(this, "Cerrando aplicación...", Toast.LENGTH_SHORT).show();
                finishAffinity();
            } else {
                // Swipe de derecha a izquierda -> Limpiar contenido
                editText.setText("");
                textView.setText("Aquí aparecerá el resultado");
                Toast.makeText(this, "Contenido limpiado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Manejar teclas de volumen correctamente
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:

                event.startTracking();
                calcularBilletes();
                return true;

            // Permitir entrada de números desde teclado físico
            case KeyEvent.KEYCODE_0:
            case KeyEvent.KEYCODE_1:
            case KeyEvent.KEYCODE_2:
            case KeyEvent.KEYCODE_3:
            case KeyEvent.KEYCODE_4:
            case KeyEvent.KEYCODE_5:
            case KeyEvent.KEYCODE_6:
            case KeyEvent.KEYCODE_7:
            case KeyEvent.KEYCODE_8:
            case KeyEvent.KEYCODE_9:
                int digit = keyCode - KeyEvent.KEYCODE_0;
                editText.append(String.valueOf(digit));
                return true;

            case KeyEvent.KEYCODE_DEL:
                String currentText = editText.getText().toString();
                if (!currentText.isEmpty()) {
                    editText.setText(currentText.substring(0, currentText.length() - 1));
                    editText.setSelection(editText.getText().length());
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void calcularBilletes() {
        String inputStr = editText.getText().toString().trim();

        if (inputStr.isEmpty()) {
            Toast.makeText(this, "Ingrese una cantidad", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double cantidad = Double.parseDouble(inputStr);

            if (cantidad < 0) {
                textView.setText("Ingrese una cantidad positiva");
                return;
            }

            // Convertir a centavos para evitar problemas de precisión
            int centavos = (int) Math.round(cantidad * 100);

            // Calcular billetes y monedas
            int b100 = centavos / 10000; // 100 pesos = 10000 centavos
            centavos %= 10000;

            int b50 = centavos / 5000; // 50 pesos = 5000 centavos
            centavos %= 5000;

            int b20 = centavos / 2000; // 20 pesos = 2000 centavos
            centavos %= 2000;

            int m10c = centavos / 10; // 10 centavos
            centavos %= 10;

            int m5c = centavos / 5; // 5 centavos
            centavos %= 5;

            // Mostrar resultado
            StringBuilder resultado = new StringBuilder();
            if (b100 > 0) resultado.append("Billetes $100: ").append(b100).append("\n");
            if (b50 > 0) resultado.append("Billetes $50: ").append(b50).append("\n");
            if (b20 > 0) resultado.append("Billetes $20: ").append(b20).append("\n");
            if (m10c > 0) resultado.append("Monedas 10¢: ").append(m10c).append("\n");
            if (m5c > 0) resultado.append("Monedas 5¢: ").append(m5c).append("\n");

            if (centavos > 0) {
                resultado.append("Restante: ").append(centavos).append("¢");
            }

            if (resultado.length() == 0) {
                resultado.append("Cantidad: $0.00");
            }

            textView.setText(resultado.toString());

        } catch (NumberFormatException e) {
            textView.setText("Ingrese un número válido");
        }
    }

    private void updateInstructions() {
        int orientation = getResources().getConfiguration().orientation;
        String instructions;

        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            instructions = "📱 INSTRUCCIONES:\n" +
                    "• Mitad inferior: Swipe → para SALIR\n" +
                    "• Mitad inferior: Swipe ← para LIMPIAR\n" +
                    "• Presiona Vol+ para CALCULAR";
        } else {
            instructions = "📱 INSTRUCCIONES: Mitad inferior - Swipe → SALIR | Swipe ← LIMPIAR | Vol+ CALCULAR";
        }

        instructionsText.setText(instructions);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateInstructions();
    }
}